
    export default function StockPage() {
        return (
            <div className="p-8">
                <h1 className="text-2xl font-bold">ERP Inventory: Warehouse A</h1>
                <p className="text-slate-500">This module was installed via ZIP!</p>
            </div>
        );
    }
    